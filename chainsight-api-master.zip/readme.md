Api Used

https://ethplorer.io/wallet/#
https://github.com/EverexIO/Ethplorer/wiki/Ethplorer-API#get-top-tokens

----> Riich List ---> Sumaray
https://api.ethplorer.io/getTopTokenHolders/0xf3Db5Fa2C66B7aF3Eb0C0b782510816cbe4813b8?apiKey=freekey&limit=100

----> RichList ---> activity

/getTokenHistory?apiKey=freekey


----> Rich List ---> Portfolio

/getTop?apiKey=freekey


-----> Trending contracts
https://api.ethplorer.io/getTopTokens?apiKey=freekey


